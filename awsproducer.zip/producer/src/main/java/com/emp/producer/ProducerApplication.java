package com.emp.producer;

import java.net.URL;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducerApplication {
//	@Value("${socket.base.port}")
//	@Value("${url}")
//  public static  String uri;
	public static void main(String[] args) throws JSONException {
//		SpringApplication.run(ProducerApplication.class, args);
		//Produce produce = new Produce();
		
		Produce produce = new Produce();
		produce.Client1("sockets", 12345);
//		produce.Client1("localhost", 12345);
		
//		produce.Client1("localhost",12345);
//		@Value("${socket.base.port}")
//		private String baeldungPresentation;
		
//		try {
//			
//		} catch (JSONException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
////		
////		
    //	produce.Client1("0.0.0.0", 12345);
		
	}

}
