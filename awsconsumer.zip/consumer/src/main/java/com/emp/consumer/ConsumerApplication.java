package com.emp.consumer;

import org.json.JSONException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.emp.consumer.Consumer;

@SpringBootApplication
public class ConsumerApplication {

	public static void main(String[] args) throws JSONException {
		//SpringApplication.run(ConsumerApplication.class, args);
		Consumer C = new Consumer();
    	C.consume();
	}

}
