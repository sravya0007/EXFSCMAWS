package com.emp.consumer;

import org.apache.kafka.clients.consumer.ConsumerConfig;  
import org.apache.kafka.clients.consumer.ConsumerRecord;  
import org.apache.kafka.clients.consumer.ConsumerRecords;  
import org.apache.kafka.clients.consumer.KafkaConsumer;  
import org.apache.kafka.common.serialization.StringDeserializer;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;  
import org.slf4j.LoggerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.stereotype.Component;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.time.Duration;  
import java.util.Arrays;  
import java.util.Collections;  
import java.util.Properties;  
@Component  
public class Consumer {  
	private static MongoCollection<Document> coll = null;
static 
	 String uri = "mongodb+srv://sravya98:hiheloS113@scmxpert.jkkrnjc.mongodb.net/SCM?retryWrites=true&w=majority";
    public  void consume() throws JSONException {
    	try
        {
        	
 //      MongoClient mongo = new MongoClient("localhost" , 27017);  
  //     MongoClient mongo = new MongoClient("localhost" , 27017);
       MongoClient mongoClient = MongoClients.create(uri);
       MongoDatabase db = mongoClient.getDatabase("SCM");  
 //      MongoCollection<Document> coll = db.getCollection("DeviceDataStream");
       coll = db.getCollection("DeviceData");
       System.out.println("Mongo connection estabished  ......");
       
        }
    
    catch (Exception e) {
        // handle server down or failed query here.
    }
        Logger logger= LoggerFactory.getLogger(Consumer.class.getName());  
//        String bootstrapServers="127.0.0.1:9092";  
        String bootstrapServers="kafka:9092";  
        String grp_id="group-id";  
        String topic="XYZ"; 
      
        //Creating consumer properties  
        Properties properties=new Properties();  
        properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrapServers);  
        properties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,   StringDeserializer.class.getName());  
        properties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class.getName());  
        properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG,grp_id);  
        properties.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");  
        //creating consumer  
        KafkaConsumer<String,String> consumer= new KafkaConsumer<String,String>(properties);  
//        Consumer consume = new Consumer();
 //       consume.coll();
 //       consume.coll = null;
        //Subscribing  
                consumer.subscribe(Arrays.asList(topic));  
        //polling  
        while(true){  
            ConsumerRecords<String,String> records=consumer.poll(Duration.ofMillis(100));
            for(ConsumerRecord<String,String> record: records){  
            	
                logger.info("Key: "+ record.key() + ", Value:" +record.value());  
                logger.info("Partition:" + record.partition()+",Offset:"+record.offset());            
                Document doc = Document.parse(record.value());
                coll.insertOne(doc);
               
            } 
            
  
  
        }  
     	         
    }  
    
}  